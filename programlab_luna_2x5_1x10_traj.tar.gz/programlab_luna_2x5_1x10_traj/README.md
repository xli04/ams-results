# Scores and trajectories by organisation setting

`scores.csv` gives, for each of 18 ProgramLab tasks, the score of GPT-6 Luna under two settings; the task folders hold
the trajectories behind those scores.

## Columns
- `task`: the ProgramLab task (repository and commit).
- `2x5`: two groups of 5 agents each.
- `1x10`: one group of 10 agents.

## Setup
- Model: GPT-6 Luna, Codex harness, reasoning effort medium.
- Time limit: 30 minutes per episode.
- Tasks: 18 ProgramLab tasks (6 hard, 12 medium).

## Score
The fraction of the task's hidden tests passed by the code. Range 0 to 1.

## Structure
```
scores.csv
<task>/
  2x5/
  1x10/
    score.json             the episode's score
    posts.jsonl            every post on the platform, in order
    agents/<agent>.jsonl   one agent's trajectory, in time order: its messages, tool calls and tool outputs
                           ("source": "codex"), and the platform's notices it received ("source": "platform")
```
